# Skip Counter

A jump-rope counter that listens for the rope hitting the floor.

## Deploy on GitHub Pages

1. Create a new public repository on GitHub (e.g. `skip-counter`).
2. Upload these files to the root of the repo: `index.html`, `rms-worklet.js`, `.nojekyll`, `README.md`.
3. Go to **Settings → Pages**. Under **Build and deployment**, set Source to **Deploy from a branch**, Branch to **main**, folder **/ (root)**, then **Save**.
4. After a minute your app is live at `https://<your-username>.github.io/skip-counter/`.

Open that link in Chrome or Safari and allow the microphone when asked.

## Microphone notes

- The mic only works on `https://` pages (GitHub Pages is https) or `localhost`. Opening `index.html` directly from your files, or inside an in-app viewer (WhatsApp, Instagram, Files preview), will block it.
- If you denied access once, the browser remembers: tap the lock / "aA" icon in the address bar, allow Microphone, and reload.
- Close calls, voice recorders or other tabs using the mic before you start.
